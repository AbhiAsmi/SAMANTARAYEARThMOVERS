# SQL_Micro_Course
Complete SQL Beginner Advance 30 Lessons Practice Files + Project Practice Files 

👉 Watch Video : <br><br>

[![Watch the video](https://img.youtube.com/vi/8IuqFU5gw1E/hqdefault.jpg)](https://youtu.be/8IuqFU5gw1E)

<br><br>
